
// const tls = require('tls');
// const path = require('path');
// const axios = require('axios');
// const cors = require('cors');
// const http = require('http');
// const https = require('https');
// const express = require('express');
// const bodyParser = require('body-parser');
// const app = express();
// const fs = require('fs');

// const privateKeyPath = './private.key';
// const certificatePath = './certificate.crt';

// const privateKey = fs.readFileSync(privateKeyPath, 'utf8');
// const certificate = fs.readFileSync(certificatePath, 'utf8');

// const httpsServer = https.createServer(
//   { key: privateKey, cert: certificate },
//   app
// );  


// module.exports = {
//     sslcert
// }